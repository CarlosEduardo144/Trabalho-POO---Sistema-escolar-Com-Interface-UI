package dados;

import controle.Aluno;
import controle.Disciplina;

public class RepoDisciplinas {
    private Disciplina[] disciplinas;
    private static int qttDisciplinas;
    private static int proxId;

    public RepoDisciplinas() {
        this.disciplinas = new Disciplina[10];
        qttDisciplinas = 0;
        proxId = 1;
    }

    public boolean add(Disciplina disciplina) {
        for (int i = 0; i < disciplinas.length; i++) {
            if (disciplinas[i] == null){
                disciplinas[i] = disciplina;
                proxId++;
                qttDisciplinas++;
                return true;
            }
        }
        return aumentarVetorDisciplina() && add(disciplina);
    }

    private boolean aumentarVetorDisciplina() {

        int j = disciplinas.length * 2;
        Disciplina[] vaux = new Disciplina[j];
        for (int i = 0; i < disciplinas.length; i++) {
            vaux[i] = disciplinas[i];
        }

        disciplinas = vaux;
        return true;
    }

    public Disciplina[] listar() {
        if (qttDisciplinas == 0) {
            return null;
        } else {
            Disciplina[] aaux = new Disciplina[qttDisciplinas];
            for (int i = 0; i < qttDisciplinas; i++) {
                aaux[i] = disciplinas[i];
            }
            return aaux;
        }
    }

    public int getProxId() {
        return proxId;
    }
}