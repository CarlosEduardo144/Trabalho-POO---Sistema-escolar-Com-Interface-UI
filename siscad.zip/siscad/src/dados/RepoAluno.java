package dados;

import controle.Aluno;

public class RepoAluno {
    private Aluno alunos[];
    private static int qttAluno;
    private static int proxCodigo;

    public RepoAluno() {
        this.alunos = new Aluno[10];
        qttAluno = 0;
        proxCodigo = 1;
    }

    public boolean add(Aluno aluno) {

        for (int i = 0; i < alunos.length; i++) {
            if (alunos[i] == null){
                alunos[i] = aluno;
                proxCodigo++;
                qttAluno++;
                return true;
            }
        }
        return aumentarVetorAluno() && add(aluno);
    }

    private boolean aumentarVetorAluno() {

        int j = alunos.length * 2;
        Aluno[] vaux = new Aluno[j];
        for (int i = 0; i < alunos.length; i++) {
            vaux[i] = alunos[i];
        }

        alunos = vaux;
        return true;
    }

    public boolean excluir(int numMatricula) {
        return true;
    }

    public boolean alterar(Aluno a) {
        return true;
    }

    public Aluno buscar(int numMatricula) {
        for (int i = 0; i < this.alunos.length; i++) {
            if (alunos[i] != null && alunos[i].getCodigo() == numMatricula) {
                return alunos[i];
            }
        }
        return null;
    }

    public Aluno[] listar() {
        if (qttAluno == 0) {
            return null;
        } else {
            Aluno[] aaux = new Aluno[qttAluno];
            for (int i = 0; i < qttAluno; i++) {
                aaux[i] = alunos[i];
            }
            return aaux;
        }
    }

    public boolean verificarCodigo(int id) {
        boolean sentenca = false;
        for (int i = 0; i < alunos.length; i++) {
            if (alunos[i] != null && alunos[i].getCodigo() == id) {
                sentenca = true;
            }
        }

        return sentenca;
    }

    public boolean VerificarNome(String nome) {
        String nm = "";

        if (qttAluno == 0) {
            return false;
        } else {
            for (int i = 0; i < qttAluno; i++) {
                nm = alunos[i].getNmaluno();
                if (nm.equals(nome)) {
                    return true;
                }
            }
            return false;
        }
    }

    public int getProxCodigo() {
        return proxCodigo;
    }
}