package ui;

import java.util.Scanner;

import controle.Sistema;
import ui.UIAluno;
import ui.UIDisciplina;

public class UIPrincipal {
    private Scanner scn;
    private UIAluno uiAluno;
    private UIDisciplina uiDisciplina;
    

    public UIPrincipal() {
        scn = new Scanner(System.in);
        uiAluno = new UIAluno();
        uiDisciplina = new UIDisciplina();
    }

    public void iniciar() {
        int opcao = 0;
        int tmnEspacamento = 12;    

        do {
            opcao = menuInicial();
            while (opcao <= 0 || opcao > 11) {
                opcao = menuInicial();
        }
            switch (opcao) {
               case 1:
				uiDisciplina.cadastrarDisciplina();
				break;
			case 2:
				uiDisciplina.removerDisciplina();
				break;
			case 3:
				uiDisciplina.listarDisciplina(tmnEspacamento);
				break;
			case 4:
				uiAluno.cadastrarAluno();
				break;
			case 5:
				uiAluno.alterarAluno();
				break;
			case 6:
				uiAluno.listarAlunos(tmnEspacamento);
				break;
			case 7:
				// listarAlunosNotas(tmndespa);
				break;
			case 8:
				// matricularAluno();
				break;
			case 9:
				// listarMatriculas(tmndespa);
				break;
			case 10:
				tmnEspacamento = definirEspaco(tmnEspacamento);
                System.out.println("O tamanho do espaçamento foi definido para: " + tmnEspacamento);
				break;
            }
        }while (opcao != 0);
		System.out.println("Você saiu do programa");
    }

    private int definirEspaco(int tmnEspacamento) {
        System.out.println("Digite o novo tamanho do espaçamento:");
        tmnEspacamento = scn.nextInt();
        return tmnEspacamento;
    }

    public int menuInicial() {

        System.out.println("- - - - - - - - - - MENU - - - - - - - - - -");
        System.out.println("1. Cadastrar disciplina");
        System.out.println("2. Remover disciplina");
        System.out.println("3. Listar disciplinas");
        System.out.println("4. Cadastrar alunos");
        System.out.println("5. Alterar aluno");
        System.out.println("6. Listar aluno");
        System.out.println("7. Listar notas");
        System.out.println("8. Matricular aluno");
        System.out.println("9. Listar as matrículas");
        System.out.println("10. Configurar largura da tabela");
        System.out.println("0. Sair");

        return scn.nextInt();
    }
}
