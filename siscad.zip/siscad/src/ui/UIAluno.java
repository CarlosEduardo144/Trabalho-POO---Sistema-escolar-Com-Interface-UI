package ui;

import java.util.Random;
import java.util.Scanner;

import controle.Aluno;
import controle.Sistema;

public class UIAluno {
	private Random rnd;
	private Sistema sistema;
	private Scanner scn;

	public UIAluno() {
		rnd = new Random();
		sistema = Sistema.getInstance();
		scn = new Scanner(System.in);
	}

	// responsavel por cadastrar/inserir aluno
	public void cadastrarAluno() {
		int cd = sistema.getProxCodigo();
		// int cd = Sistema.getInstance().getProxCodigo();
		System.out.println("Codigo: " + cd);
		System.out.println("Digite o nome do aluno:");
		String nome = scn.next();
		if (sistema.VerificarNome(nome))
			System.out.println("Este nome já existe no sistema.");
		else {
			System.out.println(
					"Qual é o endereço do aluno que deseja cadastrar? ");
			String endereco = scn.next();
			System.out.println(
					"Qual é o CPF do aluno que deseja cadastrar? ");
			String cpf = scn.next();

			Aluno aluno = Aluno.alunoGetInstance(cd, nome, cpf);
			if (sistema.cadastrarAluno(aluno)) {
				System.out.println("Cadastro de aluno realizado com sucesso");
			} else {
				System.out.println("Falha no cadastro do aluno");
			}

		}

	}

	public void alterarAluno() {
	}

	public void listarAlunos(int tmnEspacamento) {
		Aluno[] alunos = sistema.listarAlunos();

		if (alunos == null) {
			System.out.println("Nenhum aluno cadastrado.");
		} else {
			System.out.printf("%-" + tmnEspacamento + "s", "Codigo");
			System.out.printf("%-" + tmnEspacamento + "s", "Nome");
			System.out.println();

			for (int i = 0; i < alunos.length; i++) {
				if (alunos[i] != null) {
					System.out.printf("%-" + tmnEspacamento + "d",
							alunos[i].getCodigo());
					System.out.printf("%-" + tmnEspacamento + "s",
							alunos[i].getNmaluno());
					System.out.println();
				}
			}
		}
	}
}
