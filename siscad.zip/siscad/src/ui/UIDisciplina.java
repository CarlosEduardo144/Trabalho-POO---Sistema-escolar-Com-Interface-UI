package ui;

import java.util.Scanner;

import controle.Disciplina;
import controle.Sistema;

public class UIDisciplina {
   private static Scanner scn;
   private Sistema sistema;

   public UIDisciplina() {
      scn = new Scanner(System.in);
      sistema = Sistema.getInstance();
   }

   public void cadastrarDisciplina() {
      int id = sistema.getProxId();

      System.out.println("Digite o nome da disciplina: ");
      String nome = scn.nextLine();

      System.out.println("Digite o nome do(a) professor(a): ");
      String professor = scn.nextLine();
      
      Disciplina disciplina = Disciplina.DisciplinaGetInstance(id, nome, professor);
      if (sistema.cadastrarDisciplina(disciplina)) {
				System.out.println("Cadastro de aluno realizado com sucesso");
			} else {
				System.out.println("Falha no cadastro do aluno");
			}
   }

   public static void removerDisciplina() {
      // TODO Auto-generated method stub
      throw new UnsupportedOperationException("Unimplemented method 'removerDisciplina'");
   }

   public void listarDisciplina(int tmnEspacamento) {
      Disciplina[] disciplinas = sistema.listarDisciplinas();

      if (disciplinas == null) {
         System.out.println("Nenhum aluno cadastrado.");
      } else {
         System.out.printf("%-" + tmnEspacamento + "s", "Codigo");
         System.out.printf("%-" + tmnEspacamento + "s", "Nome");
         System.out.printf("%-" + tmnEspacamento + "s", "Professor");
         System.out.println();

         for (int i = 0; i < disciplinas.length; i++) {
            if (disciplinas[i] != null) {
               System.out.printf("%-" + tmnEspacamento + "d",
                       disciplinas[i].getId());
               System.out.printf("%-" + tmnEspacamento + "s",
                       disciplinas[i].getNome());
               System.out.printf("%-" + tmnEspacamento + "s",
                       disciplinas[i].getProfessor());
               System.out.println();
            }
         }
      }
   }
}
