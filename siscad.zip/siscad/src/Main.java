import ui.UIPrincipal;

public class Main{
    public static void main(String[] args) {
        UIPrincipal uiprincipal = new UIPrincipal();
        uiprincipal.iniciar();
    }
}