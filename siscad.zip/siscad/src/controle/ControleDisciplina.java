package controle;

import dados.RepoDisciplinas;

public class ControleDisciplina {
    private RepoDisciplinas repoDisciplina;

	public ControleDisciplina() {
        this.repoDisciplina = new RepoDisciplinas();
    }

	public boolean add(Disciplina disciplina) {
		if (repoDisciplina.add(disciplina))
			return true;
		else
			return false;
	}

	public Disciplina[] listar() {
		return repoDisciplina.listar();
	}

	public int getProxId() {
		return repoDisciplina.getProxId();
	}

}