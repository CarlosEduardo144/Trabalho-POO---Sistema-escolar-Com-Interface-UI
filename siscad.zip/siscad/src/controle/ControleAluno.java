package controle;
import dados.RepoAluno;

// Responsavel regras de negocio
public class ControleAluno {
	private RepoAluno repoAluno;

	public ControleAluno() {
        this.repoAluno = new RepoAluno();
    }

	public boolean add(Aluno aluno) {
		if (repoAluno.add(aluno))
			return true;
		else
			return false;
	}

	public boolean verificarNome(String nome) {
		return repoAluno.VerificarNome(nome);
	}

	public boolean excluir(int numMatricula) {
		return true;
	}

	public boolean alterar(Aluno a) {
		return true;
	}

	public Aluno buscar(int numMatricula) {
		return null;
	}

	public Aluno[] listar() {
		return repoAluno.listar();
	}

	public boolean verificarCodigo(int aaux) {
		return repoAluno.verificarCodigo(aaux);
	}

	public int getProxCodigo() {
		return repoAluno.getProxCodigo();
	}

}