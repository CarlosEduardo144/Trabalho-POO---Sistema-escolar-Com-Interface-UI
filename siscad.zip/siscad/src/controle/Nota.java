package controle;

public class Nota{
    private double valor;
    private Matricula matricula;
    private Disciplina disc;
}