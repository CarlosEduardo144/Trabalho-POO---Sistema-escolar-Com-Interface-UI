package controle;

public class Sistema {

    private ControleDisciplina controleDisciplina;
	private ControleAluno controleAluno;

	private static Sistema instance; // vai referenciar o unico objeto

	private Sistema() {
		controleAluno = new ControleAluno();
		controleDisciplina = new ControleDisciplina();
	}

	// singleton
	public static Sistema getInstance() {
		if (instance == null)
			instance = new Sistema();

		return instance;
	}

	// aluno
	public boolean cadastrarAluno(Aluno aluno) {
		return controleAluno.add(aluno);
	}

	public boolean cadastrarDisciplina(Disciplina disciplina) {
		return controleDisciplina.add(disciplina);
	}

	public boolean alterarAluno(int i, Aluno auxA) {
		return false;
	}

	public Aluno[] listarAlunos() {
		return controleAluno.listar();
	}

	public Disciplina[] listarDisciplinas() {
		return controleDisciplina.listar();
	}

	public void init() {

	}

	public boolean VerificarNome(String nome) {
		return controleAluno.verificarNome(nome);
	}

	public boolean verificarCdaluno(int Aaux) {
		return controleAluno.verificarCodigo(Aaux);
	}


	public int getProxCodigo() {
		return controleAluno.getProxCodigo();
	}

	public int getProxId() {
		return controleDisciplina.getProxId();
	}

}