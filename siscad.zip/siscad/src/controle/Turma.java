package controle;

public class Turma{
    private int ano;
    private int vagas;
    private Disciplina[] disciplinas;
    private Matricula[] matriculas;

    public void adicionarDisciplina(Matricula matricula){
        
    }

    public void adicionaTurma(Turma turma){
        
    }
}