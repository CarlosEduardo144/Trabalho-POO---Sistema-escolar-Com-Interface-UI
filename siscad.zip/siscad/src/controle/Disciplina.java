package controle;

public class Disciplina{
    private long id;
    private String nome;
    private String professor;

    private Disciplina(long id, String nome, String professor) {
        this.id = id;
        this.nome = nome;
        this.professor = professor;
    }

    public static Disciplina DisciplinaGetInstance(long id, String nome, String professor) {
        if (nome == null || nome.isEmpty() || professor == null || professor.isEmpty()) {
            return null;
        } else {
            return new Disciplina(id, nome, professor);
        }
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getProfessor() {
        return professor;
    }

    public void setProfessor(String professor) {
        this.professor = professor;
    }
}