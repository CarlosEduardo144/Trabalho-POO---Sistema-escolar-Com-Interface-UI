package controle;
import java.sql.Date;

public class Matricula{
    private Date data;
    private Aluno aluno;
    private Turma turma;
}