package controle;

public class Aluno {
    private long id;
    private String nome;
    private String cpf;

    private Aluno(int cd, String nome, String cpf) {
        this.id = cd;
        this.nome = nome;
        this.cpf = cpf;
    }

    public void setCdaluno(int i) {
       this.id = i;
    }

    public int getCodigo() {
        return (int) this.id; 
    }

    public String getNmaluno() {
        return this.nome;
    }

    public static Aluno alunoGetInstance(int cd, String nome, String cpf) {
        if (nome == null || nome.isEmpty() || cpf == null || cpf.isEmpty()) {
            return null;
        } else {
            return new Aluno(cd, nome, cpf);
        }
    }
}